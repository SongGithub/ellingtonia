ellingtonia
===========

The 'ellingtonia' is a documentation organiser.

an app created for Tangent Australia's documentation site, managing content structure by comany and project name.

Name of the app 'ellingtonia' is inspired by Guitarist Django's second album with the same name, as the app is my second Django project.

'Problem to be solved': company's documentation site needs to be more organised, by client's company names then project names. The app will run on server and dynamatically read documents' up-to-date directory structure and generate a structured view to sort projects by company name, then project names. 

It was suggested to use Flask which compromises Werkzeug, Jinja2, and 'Good intentions'. 